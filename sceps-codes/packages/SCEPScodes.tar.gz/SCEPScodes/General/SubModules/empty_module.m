%-------------------------------------------------------------------------------
%
% MODULE   An (almost) empty module header.
%
%    XXX
%
% FORMAT   xxx
%        
% OUT   x   xxx
% IN    x   xxx
% OPT   x   xxx
%
%-------------------------------------------------------------------------------
% Project:	  CIMR Algorithm Performance Evaluation
% Package:	  CIMR Scientific Work Bench
% Developer:	  Estellus 
% Contact:	  carlos.jimenez@estellus.fr 
% Initiated:	  YYYY-MM-DD
%-------------------------------------------------------------------------------


